#!/bin/bash

go build .
./geektrust sample_input/input1.txt
